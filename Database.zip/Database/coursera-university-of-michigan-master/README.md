University of Michigan - Coursera
---

This repo contains lectures and assignments of [University of Michigan - Coursera](https://www.coursera.org/umich).

<br/>
<p align="center">
  <img src="http://vpcomm.umich.edu/assets/brand/home/logo.png">
</p>

## Course Overview

| Course | Description |
|--------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| [Python for Everybody](https://github.com/tuanavu/coursera-university-of-michigan/tree/master/python_for_everybody/4_using_databases_with_python) | Python for Everybody |

## License

All Solutions licensed under MIT License. See LICENSE for further details.
