# Capstone-Retrieving-Processing-and-Visualizing-Data-with-Python
Coursera's course: Capstone: Retrieving, Processing, and Visualizing Data with Python, by University of Michigan

In the capstone, students will build a series of applications to retrieve, process and visualize data using Python.   The projects will involve all the elements of the specialization.  In the first part of the capstone, students will do some visualizations to become familiar with the technologies in use and then will pursue their own project to visualize some other data that they have or can find.  Chapters 15 and 16 from the book “Python for Everybody” will serve as the backbone for the capstone. This course covers Python 3.
